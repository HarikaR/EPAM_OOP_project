package com.harika.Project2;

import com.harika.Project2.sweet;

public class Candy extends sweet{
      Candy(String name, int wt, int cost) {
		super(name, wt, cost);
		// TODO Auto-generated constructor stub
	}

	protected String getType(){
    	  return "Candy";
      }
}
