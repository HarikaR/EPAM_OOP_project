package com.harika.Project2;
import java.util.*;
public class Gift {
   LinkedList<sweet> swts;
   Gift(LinkedList<sweet> swts){
	   this.swts=swts;
   }
   public Integer wtsans() {
	   Integer ans=0;
	   for(sweet s:swts) {
		   ans+=s.wt;
	   }
	   return ans;
   }
   public void sortChocolates(String sortp) {
	        if(sortp.compareTo("name")==0) {
	        	Collections.sort(swts,new sortbyName());
	        	
	        }
	        else if(sortp.compareTo("wt")==0) {
	        	Collections.sort(swts,new sortbywt());
	        	
	        }
	        else if(sortp.compareTo("cost")==0) {
	        	Collections.sort(swts,new sortbyCost());
	        }
   }
}
