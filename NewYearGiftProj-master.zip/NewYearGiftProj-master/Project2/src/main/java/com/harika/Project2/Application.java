package com.harika.Project2;

import java.util.*;

public class Application {
    private static Scanner in;

	public static void main( String[] args ){

    	in = new Scanner(System.in);
    	LinkedList<sweet> sweets=new LinkedList<sweet>();
        sweets.add(new Candy("cand1",10,5));
        sweets.add(new Chocolate("choc1",30,40));
        sweets.add(new sweet("cand2",20,10) {   //polymorphism
        	@Override	protected String getType() {return "candy";}});
        sweets.add(new sweet("choc2",15,20) {   //polymorphism
        	@Override	protected String getType() {return "chocolate";}});
        sweets.add(new Candy("cand3",30,15));
        sweets.add(new Chocolate("choc3",45,60));
        Gift newYear=new Gift(sweets);
        Integer totweight=newYear.Weightssum();
        System.out.println("sum  is:"+totweight);
        newYear.sortChocolates("cost");  //sort chocolates by weights
        System.out.println("sorting the chocolates");
        for (sweet s : newYear.sweets) {
        	if(s.getType()=="chocolate") {
			System.out.println(s.name);  //gift with chocolates in sorted by weight here,choc2<choc1<choc3
		}
      	}
        int lLimit, hLimit;
        System.out.println("enter the lower limit (available costs of candies here: 5,10,15)");
        lLimit=in.nextInt();
        System.out.println("enter the high limit (available costs of candies here: 5,10,15)");
        hLimit=in.nextInt();
        for (sweet s : newYear.sweets) {
        	if(s.getType()=="candy" && s.cost>lLimit && s.cost<hLimit) {
			System.out.println(s.name);
        	}
        }
    }
}
