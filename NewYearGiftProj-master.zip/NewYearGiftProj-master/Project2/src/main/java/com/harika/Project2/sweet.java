package com.harika.Project2;

public abstract class sweet {
  protected abstract String getType();
  int wt,cost;
  String name;
  sweet(String name,int wt,int cost){
	  this.name=name;
	  this.wt=wt;
	  this.cost=cost;
  }
}
